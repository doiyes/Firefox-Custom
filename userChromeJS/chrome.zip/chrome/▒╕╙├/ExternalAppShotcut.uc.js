// ==UserScript==
// @name           ExternalAppShotcut.uc.js
// @description    调用外部命令
// @author         ding
// @include        main
// @version        2018.2.3.1
// @startup        window.ExternalAppShotcut.init();
// @shutdown       window.ExternalAppShotcut.destroy();
// ==/UserScript==

location.href.startsWith('chrome://browser/content/browser.x') && (function () {

    const MENU_NAME = "快捷命令";
    const MENU_IMAGE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAByElEQVRYhe3WEXhbURQH8B8ECoVCoBAYDALDQSAQDAwKgWBhMCgMAoNBv68wKAwGhcJgUCgUCsXBIFAYFAeBwCBQCAQGHZyTbV++Zulr8h71/30P3n333P//3PM/912eUC26OMN5laQNHGKEO/zC17JJa+jhKgnHOEInRfTLIm7iGJMkvsCrFETsxARbmyTdxmsMRXY/8A6798wd49OmiFs4xRQzYa7Of+Z3U+CLdUjrGOAmF7vBAXYeEHuO68cSd3OBmcj4BC8LxNcz9k0R0mfCNGOR7RD7ouZFMRDCV8ZuiRa5StKJcPVadROl+rxq0tskvEsBfZtpl1au2Vo18Qi3Ofk7PghXryviROzAg1BDO8Vcp5gpLoXbnxck3874QcG4P9gVxvvib3lGIqs9q021L9xff6yARbREZ8xPvanolmUYKvHPV08By3q7KUR2yxJAeONiybdjUa5ScSB2obYwXsNPUa5SMd/m9sJ4T/yOG2ULILb5cGHsMp9KcIpv/7w3RPa9qgT0k3B+JrwX9V/0RWnYET7Yy/eR6IBKMRSnYyfFNKsWcCjugmcquHLfh7bIfCbO/8pREwfSrQ1fuYvgo+iAJxTCb+fIa+Ncavm8AAAAAElFTkSuQmCC";
    var APPS = [
        {
            enable: true,
            name: "host文件",
            path: "C:\\Windows\\notepad.exe",
            param: "C:\\Windows\\System32\\drivers\\etc\\hosts",
            image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAr0lEQVRYhe2WMQ6DMAxFGTswMHb0EThAB47RMbOH5B2hN+BIPQoDB6FLItGqakHFlMFf+pIVKdaLbUWuKtcRpKpn4L6nnwAAASagB27G7oHpFaDJAK11tWePbRzAARzAARzAARzgUADlcAQGY498WEj29NsW/AcghHACujWOMV5Lshyvur/FMM2rJj8nXCJVrfPASkrpUgByLICoam0GAIQFvQ2WAC3f937zv8S1qR4isUg9FOsPaAAAAABJRU5ErkJggg=="
        },
        {
            enable: true,
            name: "注册表",
            path: "C:\\Windows\\regedit.exe",
            param: "",
            image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAACZ0lEQVRIidWUT2jTcBTH36WXXpZLDo5BeyhIQUpF0HryJHgpZIFW2MWechIRBgFhuKystnSUamWDIKNEPaiMVQdT1ErpNltdaqOJCJNB0VtPBc+Fr4e0TdLWrm4F8cGD8PJ+30/y/vyIjmH8F0jsgwNQqlagO+rN42j80TgNQd4AwvU2XBkNlKphopBZHQ3eAHgDYBcLIPE5aLnSosR+cCIAXkeeN4DA+gfQ1bjp0aUWRaTJADgNzKXtH1pP3PQTliixH6SUmqWkWqKUmqX5DY4iUoyi8QJF44WTiaZUjVI1DLqqmdCqt/Nn3sBW03qfrOVJKjHjicZ3QfMboNhd+J7+hPue7owTEacjyxtAqNgCLbwBJarmR9gtsNXE1No3x+ELm4f2WqM7Qb77O1acrOm6stey5S81HIDuYf9quZd0cfP7UIA9h4ho1oDGG4Av89o2XVL2SMDp3DvzeS4Juv4Q4XrbmTOXBEklhtPA8DryrmtpC8BJXgfg8t6vgcNTt1+Abm07GjydPwS7stMXVzXHRveLExGdefQVM7n38OR2QYIMEmT4V8sIFVvwPG7AlVbNzRVksKJixZfLvSEYOZnDSuRfLQ+tOysqvTgrKo5+/DvA+ZdNhOttS0iQwWYrCBVbToAgwx1/24uzomI2W5BHA849O8BMrgLf+mez3rbGujIa3CsfOwtki6dVuG4opvi4JSJBRncrp2XDuve7nqiaTe2InlU+/V0PuoB+mHvx1VDRsQGcjhivo+DJFAcA/c20i55aeAKKxgsUkWIjAT2QBmYYzA5wiHISc7TqGDBWVCYj+l/Zbx+HxTUYxDTnAAAAAElFTkSuQmCC"
        },
        {
            enable: true,
            name: "Shadowsocks",
            path: "D:\\Soft\\Shadowsocks\\Shadowsocks.exe",
            param: "",
            image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAYCAYAAAALQIb7AAAB/UlEQVRIib3UP2hTQRwH8BsqZOjw7ncJOGZwECeHDCqKRTqIdOgiODhkKI6S0bHYUSHg875XFYl7B0cHhwwOHSwEh5K8+x6+QaTgotDBoUMc8of6kpe8mtSDW979+dz9fvd+Sv2HFjXTSMDGuSIVm14UsCngsTjunQsiu7wuls8FIRWwL2DfuPB4qUgE3tbwLwT8PkLG3YYbS0EM/LpBcAb8MYEMeke9OriwEKJfJvfE8q2Av3KQQXfh9T8jAl7TCO9zNv+Z/Wasr58ZiWKuabCdd4PhAY6z3yPXrRZGtPMbsxABfwvYEMdvkyFktxBikGwK2JmZD/BIbLgrLnyeNm4QXL6w3V7R4MMCSF8cuxUbLonjXm5oXfJgKmKsr2uQcxGwLwgfB2Uo7MyaFzXTaGxUW2lJwEZxhH0B35yKwKx5nb/zYn1dED4JeFIE0pZPlFJK2+Tm/DXh2dRUyS6vCLglLrQE9JPPmhSER0opZVy4I+BBgcPdn/8Mt9srBn5dwOYwvEfluFdTSqmKPVwVx24B6KRiD1fnY5l2epGAHwrmdf/MULaZOLks4JbAvzNgyMWsf7oQFFl/VTu/MbpptZWWRhU/Wz2imGuL3cr6uozLU9jJjpfjXm343+1XW2lpSZj/ovH11kKbFcUMks1zhUbY7MK6xFaOe7VFcvEH0kmOdJxgPVgAAAAASUVORK5CYII="
        },


        {
            enable: false,
            name: "保留不删",
            path: "",
            param: "",
            image: ""
        }

    ];

    if (window.ExternalAppShotcut) {
        window.ExternalAppShotcut.destroy();
        delete window.ExternalAppShotcut;
    }

    var ExternalAppShotcut = {
        init: function () {

            let inspos = $("urlbar-container");
            let toolbarbutton = document.createXULElement("toolbarbutton");
            toolbarbutton.id = "shotcut-extapp"
            toolbarbutton.setAttribute("label", MENU_NAME);
            toolbarbutton.setAttribute("tooltiptext", MENU_NAME);
            toolbarbutton.setAttribute("removable", true);
            toolbarbutton.setAttribute("cui-areatype", "toolbar");

            toolbarbutton.setAttribute("type", "menu");
            toolbarbutton.setAttribute("class", "toolbarbutton-1 chromeclass-toolbar-additional subviewbutton-nav");
            toolbarbutton.setAttribute("anchor", "dropmarker");
            toolbarbutton.setAttribute("image", MENU_IMAGE);

            inspos.parentNode.appendChild(toolbarbutton);

            let popup = document.createXULElement("menupopup");
            popup.id = "shotcut-extapp-popup";
            toolbarbutton.appendChild(popup);

            var len = APPS.length-1;
            var apps = 0;
            for (var i = 0; i < len; i++) {
                let app = APPS[i];
                if (app.enable) {
                    if(apps>0){
                        let sep = document.createXULElement("menuseparator");
                        sep.setAttribute("class", "shotcut-menu");
                        popup.appendChild(sep);
                    }
                    let menuitem = document.createXULElement("menuitem");
                    menuitem.id = "shotcut-extapp-menu" + i;
                    menuitem.setAttribute("label", app.name);
                    menuitem.setAttribute("oncommand", "ExternalAppShotcut.lancherApp(" + i + ")");
                    menuitem.setAttribute("class", "menuitem-iconic shotcut-menu");
                    if (app.image) {
                        menuitem.setAttribute("image", app.image);
                    }
                    popup.appendChild(menuitem);

                    apps++;
                }
            }


        },
        destroy: function () {
            let button = $("shotcut-extapp");
            if (button) {
                let menus = document.querySelectorAll(".shotcut-menu");
                for(let menuitem of menus){
                    menuitem.parentNode.removeChild(menuitem);
                }
                let pop = $("shotcut-extapp-popup");
                pop.parentNode.removeChild(pop);
                button.parentNode.removeChild(button);
            }
        },
        lancherApp:function (idx) {
            let app = APPS[idx];
            let clientApp = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
            clientApp.initWithPath(app.path);
            if (!clientApp.exists()) {
                alert("应用不存在: " + app.path);
                return;
            }
            try {
                let ss = Cc["@mozilla.org/browser/shell-service;1"]
                    .getService(Ci.nsIShellService);
                ss.openApplicationWithURI(clientApp, app.param);
            } catch (e) {
                let p = Cc["@mozilla.org/process/util;1"]
                    .createInstance(Ci.nsIProcess);
                p.init(clientApp);
                p.run(false, [app.param], 1);
            }
        }
        
    }
    ExternalAppShotcut.init();
    window.ExternalAppShotcut = ExternalAppShotcut;

    function $(id) {
        return document.getElementById(id);
    }
})();
