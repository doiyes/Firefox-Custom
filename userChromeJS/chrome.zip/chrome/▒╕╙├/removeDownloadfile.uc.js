// ==UserScript==
// @name           removeDownloadfile.uc.js
// @description    已下载文件添加“从硬盘删除”功能
// @include        main
// @include        chrome://browser/content/places/places.xul
// @version        2018.3.14.1
// @startup        window.removeDownloadfile.init();
// @note           适配Firefox57+
// ==/UserScript==

(location.href.startsWith('chrome://browser/content/browser.x') || location == "chrome://browser/content/places/places.xul") &&
(function () {

    var removeDownloadfile = {
        currentPanel: 1,
        removeStatus: function () {
            let RMBtn = document.querySelector("#removeDownload");
            if (RMBtn) {
                var listbox, node;
                let flag = removeDownloadfile.currentPanel;
                if (flag == "1") {
                    listbox = document.querySelector("#downloadsListBox");
                    node = listbox && listbox.selectedItems && listbox.selectedItems[0];
                } else if (flag == "3") {
                    listbox = document.querySelector("#downloadsRichListBox");
                    node = listbox && listbox.selectedItems && listbox.selectedItems[0];
                } else {
                    //listbox = document.querySelector("#panelMenu_downloadsMenu");
                    node = document.getElementById("panelDownloadsContextMenu");
                }
                let state = (node && node.getAttribute('state'));
                let exists = (node && node.getAttribute('exists'));
                RMBtn.setAttribute("disabled", "true");
                if (state != "0" && state != "4" && state != "5" && exists == "true") {
                    RMBtn.removeAttribute("disabled");
                }
            }

        },
        removeMenu: function (contextMenuId) {
            try {
                removeDownloadfile.removeStatus();
            } catch (e) {
                alert(e.message)
            }
            ;
            let pnl = document.querySelector("#" + contextMenuId);
            if (pnl.querySelector("#removeDownload")) return;

            let menuitem = document.getElementById("removeDownload") || document.createXULElement("menuitem"),
                rlm = pnl.querySelector('.downloadRemoveFromHistoryMenuItem');

            menuitem.setAttribute("label", rlm.getAttribute("label").indexOf("History") != -1 ? "Delete File" : "\u4ECE\u786C\u76D8\u4E2D\u5220\u9664");
            menuitem.setAttribute("id", "removeDownload");

            function removeSelectFile(path) {
                let file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsIFile);
                try {
                    file.initWithPath(path);
                } catch (e) {

                }
                if (!file.exists()) {
                    if (/\..{0,10}(\.part)$/.test(file.path))
                        file.initWithPath(file.path.replace(".part", ""));
                    else
                        file.initWithPath(file.path + ".part");
                }
                if (file.exists()) {
                    file.permissions |= 0666;
                    file.remove(0);
                }
            }

            menuitem.onclick = function (e) {

                if (e.target.disabled) return;
                if (removeDownloadfile.currentPanel == "2") {
                    //var ddBox = document.getElementById("panelMenu_downloadsMenu");
                    //if(!ddBox)return;
                    try {
                        let sShell = document.getElementById("panelDownloadsContextMenu")._anchorNode._shell;
                        let path = sShell.download.target.path;
                        removeSelectFile(path);
                        sShell.doCommand("cmd_delete");
                    } catch (e) {
                    }
                } else {
                    var ddBox = document.getElementById("downloadsRichListBox");
                    if (!(ddBox && ddBox._placesView)) {
                        ddBox = document.getElementById("downloadsListBox");
                    }
                    if (!ddBox) return;
                    var len = ddBox.selectedItems.length;

                    for (var i = len - 1; i >= 0; i--) {
                        let sShell = ddBox.selectedItems[i]._shell;
                        let path = sShell.download.target.path;
                        removeSelectFile(path);
                        sShell.doCommand("cmd_delete");
                    }
                }

            };

            try {
                pnl.insertBefore(menuitem, rlm.nextSibling);
            } catch (e) {
                alert(e.message);
            }
            removeDownloadfile.removeStatus();
        },
        removeMenu1: function () {
            removeDownloadfile.currentPanel = "1";
            removeDownloadfile.removeMenu("downloadsContextMenu");
        },
        removeMenu2: function () {
            removeDownloadfile.currentPanel = "2";
            removeDownloadfile.removeMenu("panelDownloadsContextMenu");
        },
        removeMenu3: function () {
            removeDownloadfile.currentPanel = "3";
            removeDownloadfile.removeMenu("downloadsContextMenu");
        },
        inited1:false,
        init1: function () {
        		if(removeDownloadfile.inited1)return;
        		removeDownloadfile.inited1 = true;
            document.querySelector("#downloadsContextMenu").addEventListener("popupshowing", this.removeMenu1, false);
        },
        inited2:false,
        init2: function () {
        		if(removeDownloadfile.inited2)return;
        		removeDownloadfile.inited2 = true;
            document.querySelector("#panelDownloadsContextMenu").addEventListener("popupshowing", this.removeMenu2, false);
        },
        inited3:false,
        init3: function () {
        		if(removeDownloadfile.inited3)return;
        		removeDownloadfile.inited3 = true;
            document.querySelector("#downloadsContextMenu").addEventListener("popupshowing", this.removeMenu3, false);
        },
        init:function () {
            if (location != "chrome://browser/content/places/places.xul") {
            	
                DownloadsPanel._openPopupIfDataReadyOrg = DownloadsPanel._openPopupIfDataReady;
                DownloadsPanel._openPopupIfDataReady = function(){
                	DownloadsPanel._openPopupIfDataReadyOrg();
                	removeDownloadfile.init1();
                }
                
                var times = 0;
                function checkStatus() {//等待列表弹出
                    let pnl = document.querySelector("#panelDownloadsContextMenu");
                    if (pnl && pnl.querySelector('.downloadRemoveFromHistoryMenuItem')) {
                        removeDownloadfile.init2()
                    } else {
                        times++;
                        if (times > 5) {
                            times = 0;
                            return;
                        }
                        setTimeout(checkStatus, 1000);
                    }
                }

								DownloadsSubview.showOrg = DownloadsSubview.show;
                DownloadsSubview.show = async function show(anchor) {
                    DownloadsSubview.showOrg(anchor);
                    setTimeout(checkStatus, 1000);
                };

            } else {
                //我的足迹下载项列表
                removeDownloadfile.init3();
            }
        }
    }

    removeDownloadfile.init();
    window.removeDownloadfile = removeDownloadfile;
})()