// 这是一个 addMenuPlus 配置文件
// 请到 http://ywzhaiqi.github.io/addMenu_creator/ 生成配置文件
tab([
{
    label: "addMenuPlus配置",
    tooltiptext: "左键：编辑配置\n右键：重载配置",
    accesskey: "r",
    image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAC0klEQVQ4jY3M70sTARzH8e8OZ8LccileaXjbpLbLzW535Fzt7lxuxjbnwNAS19QhlfQDQaQOSSVT+zGRQPuhPvBCRHoSFDmxgujns1L6d+I+PTBL64kPXo8+bz6UPn/+ZLarazqbTs/u1N2Zns10bOnu3L1l0+nZbCZzN93W5qbmWOxxayqFf/VcSqJ/OIH+4QR6Lif/21tTqZ+xSKSfGsNhPZlIYKdUSxz3VuJY/pHA8o8E7j+PI9US39U0x2KGKssaKaGQfiYaxbamxijOZSKY/xTD0mYCS5sJLHyOoaM7gqbGnV2jcSoY1ChQV6eHFQVhVUVYVaHKCq6MNkDfaMLDfBQP81E822jCtbEwVHlnJxsnJEkjSRD0YCCAbYoSwJ1lFfr3CK6Py7h6W8bitwgmnqtQG/529XV1huD1alTD87ooCBAFAYJPQKxVxMw7BY8/qGhulxA/K+HRexWz7xU0t4sQfL/b48cNz9GjGlVXV+u8xwPe44HH7UFW8+PJlxDGVurhl3gIfh6jSwE8/RrCxRERvHu7dRsuh0OjyspK3clxcHAc+BonhhZFzHyqR/aWD04HByfHIXPDi5mP9RhZllBT64SD4+CoqjIOsaxGpXa7fpBlwZaxOHmGw4NVEdNvJWgLXvRN8uib5HFzzovpNxJyayIaWhxgy1iw5eVGqd2ukdVi0UtsNpTYbOgYcGJqvRa5vIBc3o+ptS25vB+5vICp9Vp0Dblgt5dgv9VqWCwWjcxms15YWITyCgsG547gwZoX2dFq+GUWorLFL7O4oLlwP++FtuhGhbMYZvM+o6CgQCOGYXTGxMB/2obxVzzGXx6DL2SDiRgwpi0mYuCWijH2gsfkKo9g0g4TmQwi0oiIdCJCMHkAvRMutA8eRpGVARHtUljE4Gx/JXonXWhoKwMR/TmY/zfeo59ENEBElCKiF0S0SkSv92iViFaIKPALvt6gJtieLooAAAAASUVORK5CYII=",
    oncommand: "setTimeout(function() {addMenu.edit(addMenu.FILE);}, 10);",
    onclick: "if (event.button == 2) {event.preventDefault(); addMenu.rebuild(true);}"
},
{
    label: "KeyChanger配置",
    tooltiptext: "左键：编辑配置\n右键：重载配置",
    accesskey: "r",
    image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAC0klEQVQ4jY3M70sTARzH8e8OZ8LccileaXjbpLbLzW535Fzt7lxuxjbnwNAS19QhlfQDQaQOSSVT+zGRQPuhPvBCRHoSFDmxgujns1L6d+I+PTBL64kPXo8+bz6UPn/+ZLarazqbTs/u1N2Zns10bOnu3L1l0+nZbCZzN93W5qbmWOxxayqFf/VcSqJ/OIH+4QR6Lif/21tTqZ+xSKSfGsNhPZlIYKdUSxz3VuJY/pHA8o8E7j+PI9US39U0x2KGKssaKaGQfiYaxbamxijOZSKY/xTD0mYCS5sJLHyOoaM7gqbGnV2jcSoY1ChQV6eHFQVhVUVYVaHKCq6MNkDfaMLDfBQP81E822jCtbEwVHlnJxsnJEkjSRD0YCCAbYoSwJ1lFfr3CK6Py7h6W8bitwgmnqtQG/529XV1huD1alTD87ooCBAFAYJPQKxVxMw7BY8/qGhulxA/K+HRexWz7xU0t4sQfL/b48cNz9GjGlVXV+u8xwPe44HH7UFW8+PJlxDGVurhl3gIfh6jSwE8/RrCxRERvHu7dRsuh0OjyspK3clxcHAc+BonhhZFzHyqR/aWD04HByfHIXPDi5mP9RhZllBT64SD4+CoqjIOsaxGpXa7fpBlwZaxOHmGw4NVEdNvJWgLXvRN8uib5HFzzovpNxJyayIaWhxgy1iw5eVGqd2ukdVi0UtsNpTYbOgYcGJqvRa5vIBc3o+ptS25vB+5vICp9Vp0Dblgt5dgv9VqWCwWjcxms15YWITyCgsG547gwZoX2dFq+GUWorLFL7O4oLlwP++FtuhGhbMYZvM+o6CgQCOGYXTGxMB/2obxVzzGXx6DL2SDiRgwpi0mYuCWijH2gsfkKo9g0g4TmQwi0oiIdCJCMHkAvRMutA8eRpGVARHtUljE4Gx/JXonXWhoKwMR/TmY/zfeo59ENEBElCKiF0S0SkSv92iViFaIKPALvt6gJtieLooAAAAASUVORK5CYII=",
    oncommand: "setTimeout(function() {KeyChanger.edit(KeyChanger.FILE);}, 0);",
    onclick: "if (event.button == 2) {event.preventDefault();KeyChanger.makeKeyset(true);};"
},
 {label: "复制页面网址",
   text: '%URL%',
   insertBefore: "context_closeTab",
   image:" "
},
{label: "复制站点标题",
   text: '%TITLES%',
   insertBefore: "context_closeTab",
   image:" "
},
{label: "复制站点标题和地址",
   text: '%TITLES%\n%URL%',
   insertBefore: "context_closeTab",
   image:" "
},
{
    label: "破解右键防复制",
    url: "javascript:{document.body.oncontextmenu=document.body.onmouseup=document.body.onmousemove=document.body.onclick=document.body.onselectstart=document.body.oncopy=document.onmousedown=document.onkeydown=function(){};alert('ok');}",
    image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEZSURBVDhPjZExisJQEIYfrIW4HsBOq8VLLCoiKjYeQNAykHZBRQW9gPZewkJBiwVLL7B3sBRLC2c2M5mJL9FH/OEneZP//5L3Ykjj6Rxd5kCaXhVtS8wtDSb1NsQG2KWkJf4sDaQByFKJSx/aANjvEQYDnpFodqjVcdPuPEOSgNloglAoYJBEWK14vu71eX37yODS8+OQJIDvj8cQkM0i7HZ4/czzettoRhmpOwCBfr8r0VsZ1u3yXDNSdwNIUCyG5VwO8XLhmWak7gbovu8ECEyfT9KM1B8A23g+Pw7S98MrncfpFGWk/hoA1SqX/r7KvNbzgFIJFz9Dnkk9LnrAv9HzOKz7JhEUWq10gFqDrrVU4rIDaTbGmH8Vxu1dx2qGHAAAAABJRU5ErkJggg=="
},
]);


page([{
    label: "复制图像的 Base64",
    text: "%IMAGE_BASE64%",
    condition: "image"
},
{
    label: "复制链接文本",
    text: '%LINK_TEXT%',
    condition: "link",
    insertBefore: "context-copylink"
},
{
    label: "生成百度短网址",
    insertBefore:"context-sep-viewsource",
    oncommand: function() {
        var url = addMenu.convertText("%RLINK_OR_URL%");
        var form = new FormData();
        form.append('url', url);
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "http://dwz.cn/create.php", true);
        xhr.onload = function() {
            var obj = JSON.parse(xhr.responseText);
            if(obj.status==-1){
                addMenu.copy("不支持");
            }else{
                addMenu.copy(obj.tinyurl);
            }
        }
        xhr.send(form);
    }
},
{
	   id:"context-reloadframe",
    label: "刷新此页",
    insertAfter:"context-sep-ctp",
    image:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAHwElEQVRoge2a/UscSRrHm4MlsCyEJXAEwsGxLAQh8Yd1deyo/f4y3dM9Pd093TPTMxudrJobXGNe0L24XlCDSdaYZJPsJZig50bdm3M35xqGccXomBEVmyawWQIH/nB/ynM/eOO5njo9L1kDd194fuququdTVf1U1VONIP/X/5gcx3mnt7f3Nwfth2vNPktWDw0ONF/oSFyNN1rDuq4kFUX6XpalaVmWpjVNScYbreHOS+1X7t+9aS0uzh4vtc2JsRGuHL4jU98+wS90JK5KPmGmHsPWCJIAjmdBlkRQVT9omgK6vmmq6gdZEoFlGcBwHHACz4bD+vjQ9f7Wn1ZWflto22MjD/wUTS2UBPDo4Ve6YQQmURS1GYYGTVMgEg6CFTEgEg7mtdx7suyD+oZ6oGhqobvr4mXHcQ67aT+T+fHDEydPbMQsc7QogNmnyeqwqY+jKGpLkgBRy3Dt/F4WtQwIBgOA4ThQNLVw++a1+H4+OI5zmCCILEES0NLSdK9giJ7urs89tbWO18uXBWA3IE1TwFNb60QjwbFXr5bf380PUeRTHM+C3y9B85nGrwuCiEaCYyiK2uGQXnaAnVMuahlAMzSQFLn0w3fjDdv9CBnaJEmRS7GoCZIkuAfZ2EgfEkU+RZKbhd8UwE6LRU2QZR94PB5n6ttRCkEQ5NxniWsNGLaS86MgEJ/PO0MzNBQKYRoq+P0SiKIXBIEHQeDB75fANFTXIxq1DNB1BSSfMHPmzCcPRdGbilr/KesapPF05DFO4Fk3EFZks1GaoQEnCBBFPhWzzNGzrU132hKtg4nEp7diMXOU5dg5nCBAlkSwIvm/MyuyGQhkSfyvZ65A7g592VhdU/Nyew/kiziiyKe6uy5e/vvUE/z168x7u9Vr25mjD+7etqKR4Fhdfd2aokgFj7ZrEMdxDjdg2EowGNi3x2JREzieBZIilwav97c6jvNu3mHepr8MPwiIIp+iaKqoKJgXpPNSxxWCJGC/0YhFza2VeXV14VghADs67Z2W5qZ7aN0p281Ucw3iOM67FE0tmIa6LwRJkkvxRmu4WICd6u66eBlFUTv3XZQMMvLovn6qvm7PyqyIAaLoBVX1T5ULIqerfT3tPM+lwyG9dJBLF9r7WJbZs3A4pEMDhq0sLz//oNwgCIIgmqYk/X6pdBCOY+eqa2qAoqhd7WTlSYjHY2WbUtv14O5tSxC4dMjUSgeZfZasnn2arJ5LTVftZn+bHGX2Cq2lKDkxwlXX1LwMmVp5vpGD0Iv5VAVad8pWVX/5otavLcdxDpMkuSRL4r7h/q0H8fm8MxzPFrW6vzUgMcscLWVX/VaAxOOx4crKyn/Isg98PqEowwkCwqY+fmAQf75/K8Qw9HxLc9O91ubGr4u1SDg4du6zxLVfVL68/PwDQeDSjacjj+ON1nAx1nzmk4eyLE0XnRAohzJzqRNVH38MkiSALImFm+wDlmXgo6qqnzOZHz88MJDFxdnjFEWB233ObluXzWPpE/zAIEoFiUVNQFHU7u/94vyBQpQCEouaQFLk0ulY6PFBMyAIUhxI1DJAkgRgGHr+oP3fUqEgVsQA01DBU1vrvJhPVZTbn9evM+/Zdubo+vr6kfX19SO2nTm6urpwzH7x4ndrmczvn8/OVJYFJGRqwHLsXNmy4TuEE3iWZuitVBLPc8DxLLAcCzhBgMfjcXa9qigUJBgMvLEpdf/uTctTW+uYhgrBYABMQ92ykKkBw9DQ3tZyY9fCxUwtQeDS5Ty358Rx7Jyq+vdsF0VRe+KbR0JZQHIRqwHDVtoSrYPlgmhLfHqLJMmlvbb0uq4Az3PpPSsoNvxGLQPqMWztbGvTnVIhrnR3ddbV163tBRG1DGjAMOj90+WLZQfJNYATeFbTlOSe0WQfOY5zuC3ROliPYWu56bPXaBAEkd1Ipw8VBGJFDAiZGvA8B7qu5E3YiaIXcALPXuhIXH32NFmbD2BxcfZ4f+8X5wWBS+fLNsaiJng8HmdocKA5b6XbQXLJY57n0pcutPcpivS9okj7wlgRA8IhHViW2Rqh9raWGwN9Pe1DgwPNX17v/8OVnj92tiVaB8OmPk7R1AJFUa46iWFoMIzAZN7h3Q6Suzmqrql5+ejhVzqCIMhcaqoKRVFblkTXx1JV9YMg8EDRFJAkCRRFAcPQIIpeCARkcHNpFIua/z5E4VlX2ZsciBUxQFEkQFHUHht54N/+zlxquoogiCzPc0Vn0AuxHERdfd2a66vsxcXZ4wxDgyQJgNadsndeeeW0urpwTBS9KZzAs2/iHnE7BMsyQBBENjOXOuEKAkE2T4gfVVVBA4atuIk8Z1ub7lTX1LxUVX/BaZx8EdA0VEBR1NZ1Jbm+vn7ENQSCIMgP3/31VEVFxT8Lyenev3UzRpLkEkmSruZ7PoCQqQFFUYATeLa/d5+1Yj9l5lInilkDXr1afr+j/eyNegxbo+jNCFTITwMhUwNZEqEBw4AkyaXz5xLXSrlvKVkv5lMVnZfa+0SRTzVgGFA09YvfOFTVD4GADLLsA6+XB4qiAMNxYBh6PhYzR4cGB5oPFGCnNtLpQxNjI1xPd9fn8XhsWNeVpKr6pzRNSYYMbbLxdORxR/vZGwNXr7RNfPNIsO3M0YP22bV+rV+c/gUsAz0OiBlhYAAAAABJRU5ErkJggg=="
},
{
	id:"context-viewframeinfo",
    label: "查看本页信息",
    insertAfter:"context-viewinfo"
},
{
	id:"context-viewframesource2",
    label: "查看本页源代码",
    insertAfter:"context-viewsource",
    oncommand:"gContextMenu.viewFrameSource()"
},      
 {
	id:"context-viewframesource333",
    label: "浏览器工具箱",
    insertAfter:"context-viewsource",
    oncommand: 'const { BrowserToolboxProcess } = Cu.import("resource://devtools/client/framework/ToolboxProcess.jsm", {});BrowserToolboxProcess.init();'
},
{
    label: "强制刷新",
    oncommand:"BrowserReloadSkipCache(event)",
    insertBefore:"context-sharepage",
    image:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAC6UlEQVRoge2aXWvUQBSG3x8k/gD/jAhKKVrabpLNdyhS8E5twWK1spOZTFosRQWLlAoFoeJFQRB6oxREEJbeKCKFsmbXi7LLNs1uJskkWT8eOHfzcZ6d2bOZzAL/+ddosmtQgqt1pyGOwzbRJG2orJcaOjmCy1cLz2nQfQmZAzDprlDi40IjbbjrTnYJ/wAq6xUTMOghVNZDg3YLiwyCRjC5KjS/Ey5jZqWTX8QJtuQLXFihr2NzsPj8ufaZUelpqQL96M9hcT05j1j7bBIlr8KosNn2WAlhET24UXnyw6G0Iphsb6SEsEidEqLxV0ikimjkCxqtKPvANILNdmDx2cRxPb4A3f9UjUi8vImERo5h8un0ZR5C99+XK5J1IC9czCQwjMaulyNi8ml5+zMDKo1yl/dEdPqhcok+GvkhT0S0s8uXpItkmV9IZH5tdKdbD8pZDQC5q1kiDtuEE2zBDjYSw2R7I0trEUz2Jl+5L+lDzYXH1uRXrarJ85s1kSJFJSZCRIZE7SIq62H2YefPFmmSj9JW44KIy5fKG7xKvIBg7nFxgbm1X3DC5fpEHL5SWEJpRTDpbn0SMkQatAuF/qxXQoZI7WWwT1GRiSGvSIN2pbyMjmMFM3D4bdihASu04fEFeOEi3OAOPH4XTsDkikh7Gx5DpLAkXlXkFSkDnRwJHXsTKfIdkY3IdjboO/kiMmUKzzcJ5Velp0LzKPSkXBGV9UZXkzGYXM00h86myhcZCLFnqQIuX830CkhpRamXQNJFhkMj39EkbWjkGAo9KXf7Jok0WhEMeggAsIOntVz0DIcVzGQXadAuDP/gXBs72KhNQvjpIS4Sv/Lq44WLlUvYwRMxCeDshDj36Kyjw/3U9v2tV1bygwvR0BaXAPB8c/0Kbt7vwA3vCXfS/M+lieQ92+ztvLz0+tWLy5k7WqEmXaLIfUthXL5aKPkmadcrEEdnUzDofvrjBvkG038Ljy/UnbI4Ff3F6Tc0sMQvqxt0UAAAAABJRU5ErkJggg=="
}, 
{label: '字符编码选择',
          id: "charsetMenu",
      insertAfter: "context-selectall",
      condition: "noselect nolink noimage nomedia noinput",
          accesskey: "",
          clone: false,
      image:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABa0lEQVQ4jX3TsUvVURQH8M/QFBIiIo0hDiERIiERIuIgDQ3h0CQij4c8HEQiGiJaHBxEHBwc5SERESLyeIg4NImDk4hI+AdESP9Dwzk/vO+lfuHAvffc8z3nfO+5/I8e1PAVJ2nfUMejW+53oIY/2Mc8xvEq13u4xsJdwRu4xMg9CZ7jHJvdjgYuMIjVwlaypRK9OMNSddCHv3iGJzjG67QDvMRo0Q48zZgBWBaCSYK9ItsWJvALn3BV+Jr4AG28KwjaWWavUH5S6ANHBcFbHMreK+F60MLPtGk8yJJb2C0IhrOyDgLZ75e06vxx7j8LzToIWkULstxFTOGNEO5jBmwIcWFGiGwJ37sIXuR6LTVo5365INjBe0KsazEkFUFTzMEpxvAjSQ5zPyyesb/KWhdT2I+hzDrp5t1L9AndGt2O1RRl7JagCqOZaP2uC7P4LcRpCCGnxAdqi482f08C8DCJtt3MQxNz6evAP+1ATSn/vX8MAAAAAElFTkSuQmCC"
}
,]);

var Quickpostsub = PageMenu({
    label:"快速回复，论坛灌水",
    condition:"input",
    insertAfter:"context-delete",
    oncommand: function(event){
               var input_text = event.target.getAttribute('input_text');
                           if(input_text) {
                           addMenu.copy(input_text);
                           goDoCommand("cmd_paste");
                           }
                           },
    image:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACBElEQVQ4jWNgIBGcaSm3ebxh8tLvz48rkKqX4ezUdpW7Czvf/n62//+/j5evNjQ0MBGtefn2ww4PHjx4//Le2f9/3l74/3DNtMv358/nIEqzXmy7k7xP3mu/4p6/7z9+/v9459q923Kj+QjrbGhg0girrVIOLv9rmtnz36dl0f9lu09c/fTpkwgRtnaLKQVU7tRLbPvvWjP/f87iff89GxZdNo9uIGyzSlC1hUpQ5WPzvMn//dpX/W/ZeuF/2pydHzXi2tQIOlk9qLZANbT6p23p7P/+XWv/9+2+/r9p0/n/1oXTw/A7ObpTRsGraKdqaOV/m5LZ/33a1/zv3H71f9+eG/8965fOxKv5+cPbWpvmT3prFV/+3ziz/79j1cL/TZuv/u/bc/t/ZP/mkwyhDWx4Dfh850zNjrnd/4tbJvxduGjh/+LFB/937Lz9P2n6jrc2+TPl8PubgYHh0dFNh58dWPv/z8Mr/29evfi/au35/5lz9/+3Lp4RRFBzgoICx5F5fd9/P7vz/9+PL/9v3Xv0f+/23f9TavsWE9TMwMDAECYgYOcjJvr/7rFD/z9ev/j/8c7NHy/Mn7PeoKBBgCgD/BgYIgIZGNYWmhu2n2ooCXtRFavzqjTK4E1ulNn75CC7t+G+bi+9PYIe2zlG3TG0jLuhYph0UUov5Yyotg1RFhACAC/T/y29dV6BAAAAAElFTkSuQmCC"
});

Quickpostsub([
{label:"虽然不知道LZ在说什么",input_text: "虽然不知道LZ在说什么但是感觉很厉害的样子～",image:" "},
{label:"谢谢你的解答~~~", input_text: "非常感谢你的解答！！！",image:" "},
{label:"不用客气~~~", input_text: "不用客气，大家互相帮助……\u256E\uFF08\u256F\u25C7\u2570\uFF09\u256D",image:" "},
{label:"看起来很不错~~~", input_text: "看起来很不错哦，收了~~~\n谢谢LZ啦！！！",image:" "},
{label:"谢谢楼主分享~~~", input_text: "谢谢楼主的分享!这个绝对要顶！！！",image:" "},]);
