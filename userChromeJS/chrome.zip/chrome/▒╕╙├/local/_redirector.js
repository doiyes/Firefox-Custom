﻿rules = [
{
    name:"去除卡饭链接中的highlight",
    state:true,
    from:/^(http:\/\/bbs\.kafan\.cn\/.*?)&highlight=(.*)/,
    to:"$1$2",
    regex:true
 },
{
name:"去除链接中的highlight",
state: true,
from: /^(http:\/\/www\.zasq\.net\/.*?)&highlight=(.*)/,
to: "$1$2",
regex: true
}

];