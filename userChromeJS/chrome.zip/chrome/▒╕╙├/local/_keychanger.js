keys['a'] = "gBrowser.selectedTab = gBrowser.addTrustedTab('about:config');";//参数设置
keys["Alt+Q"] = "BrowserUtils.restartApplication();"; //删除启动缓存并重启

