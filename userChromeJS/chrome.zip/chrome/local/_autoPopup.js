nDelay = 290;//延迟毫秒数
//禁止自动弹出的(按钮)黑名单。CSS语法: #表示id  .表示class
blackIDs = [
'#pocket-button',
'#alltabs-button',
'#PanelUI-menu-button',
'#QuickTranslate',
'#QuickSnapshot',
'#_0981817c-71b3-4853-a801-481c90af2e8e_-browser-action',
'#firefoxcolor_mozilla_com-browser-action',
'#Sidebar-button',
'#weibopic_ac-browser-action'
]; //'.bookmark-item',

//by xinggsf, 白名单，及触发动作
whiteIDs = [
{//下载面板
	id : 'downloads-button',
	popMenu : 'downloadsPanel',
	open: btn => DownloadsPanel.showPanel(),
	close: menu => DownloadsPanel.hidePanel(),
},
{
	id : 'alertbox_tb_action',
	popMenu : 'alertbox_menu_panel',
	open : btn => btn.click(),
},
];